javascript_CVE.csv                     有CVE编号的js语言漏洞patch           共计179
javascript_notCVE.csv                没有CVE编号的js语言的漏洞patch    共计179
python_CVE.csv                            			      共计113
python_notCVE.csv					      共计115
C_CVE.csv						      共计173
C_notCVE.csv					      共计66
PHP_CVE.csv                                                                                   共计449
PHP_notCVE.csv                                                                              共计607
第一列为漏洞描述，第二列为CVE编号，第三列为CWE，第四列为patch
总计：有CVE的patch 共计914
         没有CVE的patch 共计967