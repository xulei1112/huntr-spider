C_CVE.csv 有CVE编号的C语言漏洞patch
C_notCVE.csv没有CVE编号的C语言的漏洞patch
第一列为漏洞描述，第二列为CVE编号，第三列为CWE，第四列为patch